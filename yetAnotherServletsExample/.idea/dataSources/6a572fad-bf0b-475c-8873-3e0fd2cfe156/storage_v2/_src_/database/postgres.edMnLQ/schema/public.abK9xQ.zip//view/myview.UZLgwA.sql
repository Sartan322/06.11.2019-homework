create view myview(studid, studname) as
SELECT student.studid,
       student.studname
FROM student;

alter table myview
    owner to sartan;

